package isep.util;

public class InputParser {
}
