package isep.rpg;

import isep.util.InputParser;

import java.util.*;


public class Game {

    public static Game context;
    int nbEnemies;


    public static void playGame() {
        if (Game.context != null) {
            throw new RuntimeException
                    ("Impossible de lancer plusieurs fois la partie...");
        }
        Game.context = new Game();
        Game.context.generateHeroes();
        Game.context.startCombat();
    }

    public static enum Status {START_COMBAT, HERO_TURN, ENEMY_TURN, END_GAME }
    public Status status;



    private List<Hero> heroes;
    public List<String> getHeroesStatus() {
        List<String> heroesStatus = new ArrayList<>();
        for (Hero hero: this.heroes) {
            heroesStatus.add
                ( hero.getClass().getSimpleName()
                + "(" + hero.getLifePoints()
                + "," + hero.getManaPoints()+")"
                );
        }
        return heroesStatus;
    }
    private List<Enemy> enemies;
    public List<String> getEnemiesStatus() {
        List<String> enemyStatus = new ArrayList<>();
        for (Enemy enemy: this.enemies) {
            enemyStatus.add
                ( enemy.getClass().getSimpleName()
                + "(" + enemy.getLifePoints() + ")"
                );
        }
        return enemyStatus;
    }
    private List<Fighter> fighters;
    ListIterator<Fighter> fightersIterator;

    private Fighter currentFighter;

    private int playerTurn;
    private InputParser inputParser;

    // L'instanciation de "Game" ne peut se faire que par "playGame"
    private Game() {}

    public void startCombat() {
        // Combat avec de nouveaux ennemis tant qu'il y a des héros actifs
        if (this.heroes.size() > 0) {
            this.status = Status.START_COMBAT;
            generateCombat();
        } else {
            this.status = Game.Status.END_GAME;
        }
    }

    public void chooseHereos(){

    }

    public void generateCombat() {
        generateEnemies();
        shuffleFighters();
        // Initialise un "curseur" pour parcourir la liste des combattants
        fightersIterator = fighters.listIterator();
    }

    private void generateHeroes() {
        Scanner scanner = new Scanner(System.in);

        this.heroes = new ArrayList<>();
        System.out.println("Choisissez le nombre de guerrier : ");
        int nbWarrior = scanner.nextInt();

        for (int i=0; i< nbWarrior; i++){
        Hero heroWarrior = new Warrior();
        this.heroes.add(heroWarrior);}

        System.out.println("Choisissez le nombre de hunter : ");
        int nbHunter = scanner.nextInt();

        for (int i=0; i< nbHunter; i++) {
            Hero heroHunter = new Hunter();
            this.heroes.add(heroHunter);}

        System.out.println("Choisissez le nombre de healer : ");
        int nbHealer = scanner.nextInt();

        for (int i=0; i< nbHealer; i++){
        Hero heroHealer = new Healer();
        this.heroes.add(heroHealer);}

        System.out.println("Choisissez le nombre de mage : ");
        int nbMage = scanner.nextInt();

        for (int i=0; i< nbMage; i++){
            Hero heroMage = new Mage();
            this.heroes.add(heroMage);}

        this.nbEnemies = nbHealer + nbMage + nbHunter + nbWarrior;
        System.out.println("Nombre d'enemy : " + nbEnemies);

        }

    private void generateEnemies() {

        this.enemies = new ArrayList<>();
        for (int i=0; i< this.nbEnemies; i++){ //nombre de hero meme que nombre enemy à modifier
            enemies.add( new BasicEnemy() );

        }
       //--> un seul ennemi pour l'instant !
    }

    // Mélange les héros avec les ennemis dans une liste pour le combat
    private void shuffleFighters() {
        this.fighters = new ArrayList<>();
        this.fighters.addAll(this.heroes);
        this.fighters.addAll(this.enemies);
        Collections.shuffle(this.fighters); //--> google "java shuffle list"
    }

    public void startNextFighterTurn() {

        if (this.heroes.size() == 0) {
            this.status = Game.Status.END_GAME;
        } else if (enemies.size() == 0) {
            this.status = Game.Status.START_COMBAT;
            generateCombat();
        } else {

            // Récupère le combattant suivant en déplaçant le curseur de liste
            if (!fightersIterator.hasNext()) {
                // Si on est à la fin de la liste, l'itérateur est réinitialisé
                fightersIterator = fighters.listIterator();
            }
            this.currentFighter = fightersIterator.next();

            if (this.currentFighter instanceof Hero) {
                //--> "instanceof" permet de valider si la variable "fighter",
                //    qui est de type "Fighter", contient bien une instance de la
                //    sous-classe "Hero".
                this.status = Game.Status.HERO_TURN;
            } else {
                this.status = Game.Status.ENEMY_TURN;
            }

        }
    }

    public void startHeroTurn() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Choisissez ce que vous voulez faire (1 = attaquer, 2 = defendre, 3 = utiliser un item : ");
        int action = scanner.nextInt();
        switch (action) {
            case (1):
                Fighter ennemy = this.enemies.get(0);
                boolean ennemyDefeated = this.currentFighter.attack(ennemy);
                if (ennemyDefeated) {
                    this.enemies.remove(ennemy);
                    this.fighters.remove(ennemy);
                }
            case (2):
                //Hero.defend();

            case (3):
                //Use items
        }

    }


    public void startEnemyTurn() {

        Fighter hero = this.heroes.get(0);
        boolean heroDefeated = this.currentFighter.attack(hero);
        if (heroDefeated) {
            this.heroes.remove(hero);
            this.fighters.remove(hero);
        }
    }

}
