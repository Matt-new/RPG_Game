package isep.rpg;

public class Food implements Consumable {
}
