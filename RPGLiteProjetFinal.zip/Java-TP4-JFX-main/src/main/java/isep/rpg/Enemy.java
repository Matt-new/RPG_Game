package isep.rpg;

public abstract class Enemy extends Fighter {}
