package isep.rpg;

public class Healer extends SpellCaster {

    public Healer() { this.setLifePoints(50);this.setManaPoints(4);}



    @Override
    public boolean attack(Fighter enemy) {return enemy.receiveAttack(2);}

}
